<?php

$password = $_REQUEST['password'];



if($password == "bros"){

header('Location: logon.php');
}
elseif($password == "bros"){

header('Location: logon.php');

}
}
				
?>
