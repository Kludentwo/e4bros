<form method="post" action="godkend">

				Password:<br>
				<input type="password" name="password"><br>

				<input type="submit" value="Login">

</form>