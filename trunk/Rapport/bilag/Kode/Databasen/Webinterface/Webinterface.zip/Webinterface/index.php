<head>
	
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="images/style.css" type="text/css" />
	<title>BROS</title>
</head>
<body>
	<div id="page" align="center">
		<div id="toppage" align="center">
			<div id="date">
				<div class="smalltext" style="padding:13px;"><strong>December 2012</strong></div>
			</div>
			<div id="topbar">
				<div align="right" style="padding:12px;" class="smallwhitetext"><a href="?page=shippas">Log p�</a></div>
			</div>
		</div>
		<div id="header" align="center">
			<div class="titletext" id="logo">
				<div class="logotext" style="margin:30px">BROS</div> 
			</div>
			<div id="pagetitle">
				<div id="title" class="titletext" align="right">Webinterface</div>
			</div>
		</div>
		<div id="content" align="center">
			<div id="menu" align="right">
				<div align="right" style="width:189px; height:8px;"><img src="images/mnu_topshadow.gif" width="189" height="8" alt="mnutopshadow" /></div>
				<div id="linksmenu" align="center">
					<a href="?page=shippass" title="Log p� BROS database">Log p�</a>
				</div>
				<div align="right" style="width:189px; height:8px;"><img src="images/mnu_bottomshadow.gif" width="189" height="8" alt="mnubottomshadow" /></div>
			</div>
		<div id="contenttext">
			
		
			<?php 
				if ($_REQUEST['page'] == '')
					include 'shippass.php';
				
				else if(file_exists($_REQUEST['page']. '.php'))
					include $_REQUEST['page'] . '.php';
				
				else
					include '404.php';
				?>
					
			
		</div>
		<div id="footer" class="smallgraytext" align="center">
			<a href="?page=ship">Log p�</a><br />
			BROS &copy; 2012<br />
		</div>
	</div>
</body>
</html>
