<div class="bodytext" style="padding:12px;" align="justify">
				<strong>V&aelig;lg skib			  </strong><br />
				<br />
			<a href="?page=bros">Martha</a>
			
			<?php 

  			if(is_null($GET["page"])) { 
  			  $page = "bros"; 
			  }else{ 
 			   $page = $GET["page"]; 
 			 } 

  			 include($page); 

?>
			</div>
