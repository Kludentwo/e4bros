
<?php

$password = $_REQUEST['password'];



if($password == "bros"){

	header('Location: logon.php');
}

if($password == "admin"){
	header('Location: index.php');
}

?>
