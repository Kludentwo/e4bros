<head>
	<META http-equiv="REFRESH" content="5"; /> 
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="images/style.css" type="text/css" />
	<title>BROS</title>
</head>
<body>
	
	
			<div class="bodytext" style="padding:12px;" align="justify">
				<strong>Skibs data for Martha			  </strong><br />
				<br />
				
   		
				<?php
				$filename = 'ship.txt';
				$date_ = 0;
				
				
  				
				if (file_exists($filename))
				{
				$con = mysql_connect("localhost","root","5758");
				if (!$con)
  				{
 				 die('Could not connect: ' . mysql_error());
  				}
  				
				$file_handle=fopen("ship.txt", "r");
			
				$line_of_text=fgets($file_handle);
				$parts=explode(' ',$line_of_text);	
				
				
				$date_ = $date_ = date("d/m/y : H:i:s", time()); 	
				mysql_select_db("ship", $con);

				mysql_query("INSERT INTO bros (ID, VBTE1, VBTE2, HS, KI, OPDATE)
				VALUES ('$parts[0]', '$parts[1]','$parts[2]','$parts[3]','$parts[4]','$date_')");

				
				
				echo "Database sidst opdateret ";	
				echo "<br />";
				$date_ = date("d/m/y : H:i:s", time());
				echo $date_;
				
				unlink($filename);
				mysql_close($con);

				}
				else
				{
				
					
				$con = new PDO('mysql:host=localhost;dbname=ship', 'root', '5758');
				$stmt = $con->query('select OPDATE from bros order by OPDATE desc');
				$opdate = $stmt->fetchColumn(0);
				
				if ($opdate !== false) 
				{
					echo "Database sidst opdateret ";	
					echo "<br />";
    				echo $opdate;
				}
				else
				{
					echo "Fejl med opdateret tid og dato";
				}
    

				mysql_close($con);
	

				}
				
				
				?> 

			

		


	
		<?php
	

		include 'mysql.php';
	
		$sql = new mysql("localhost", "root", "5758", "ship");
	
		$data = $sql->query("SELECT * FROM  bros order by OPDATE desc");
	
		//print_r($data);
	
		//echo '<br />Num Rows: ' . $sql->numRows();
	
		?>
		
		
		<br />
		<br />
		<table border ="1">
		<tr>
			<td style="text-align:center;"><p>ID p&aring; skib</p></td>
			<td style="text-align:center;"><p>Styrbord vandstand</p></td>
			<td style="text-align:center;"><p>Bagbord vandstand</p></td>
			<td style="text-align:center;"><p>H&aeligldning i grader</p></td>
			<td style="text-align:center;"><p>Skib tilsluttet</p></td>
			
			
			
			
		</tr>
		<?php
		
		if($sql->numRows() < 1)
			die("No Data");
		if($sql->numRows() == 1)
		{
			$data[0] = $data;
		}
		
		for($i = 0; $i < $sql->numRows(); $i++)
		{
			echo '<tr>
					<td style="text-align:center;">' . $data[$i]['ID'] . '</td>
					<td style="text-align:center;">' . $data[$i]['VBTE1'] . '</td>
					<td style="text-align:center;">' . $data[$i]['VBTE2'] . '</td> 
					<td style="text-align:center;">' . $data[$i]['HS'] . '</td> 
					<td style="text-align:center;">' . $data[$i]['KI'] . '</td>  
					
					
					
					
				</tr>';
		}
		
		?>
	</table>
	</div>
	
</body>
</html>
