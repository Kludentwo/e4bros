<?php
class mysql
{
	public function __construct($host, $username, $password, $database)
	{
		$this->setHostname($host);
		$this->setUsername($username);
		$this->setPassword($password);
		
		$this->connect();
		
		$this->setDatabase($database);
	}
	
	public function __destruct()
	{
		$this->disconnect();
	}
	
	public function setHostname($host)
	{
		$this->mysql_host = $host;
	}
	
	public function setUsername($username)
	{
		$this->mysql_username = $username;
	}
	
	public function setPassword($password)
	{
		$this->mysql_password = $password;
	}
	
	public function setDatabase($database)
	{
		$this->mysql_database = $database;
		mysql_select_db($database) or die(mysql_error());
	}
	
    public function getDatabase()
    {
        return $this->mysql_database;
    }
        
	public function connect()
	{
		$this->mysql_connection = mysql_connect($this->mysql_host, $this->mysql_username, $this->mysql_password) or die(mysql_error());
		$this->mysql_connection_open = true;
	}
	
	public function disconnect()
	{
		if(!$this->mysql_connection_open)
			return 0;
		
		mysql_close($this->mysql_connection);
		$this->mysql_connection_open = false;
	}
	
	public function query($query = "")
	{
		if($query == "")
			$query = $this->mysql_query;
		else
			$this->mysql_query = $query;
			
		$query_ = mysql_query($query) or die(mysql_error() . "<br />" . $query);
		$tmp = array();
		
		if($this->numRows() == 1)
		{
			while($data = mysql_fetch_array($query_))
			{
				$tmp = $data;
				break;
			}
		}
		elseif($this->numRows() > 1)
		{
			$i = 0;
			while($data = mysql_fetch_array($query_))
			{
				$tmp[$i] = $data;
				$i++;
			}
		}
		else
			return false;
		
		return $tmp;
	}
	
	public function numRows($query = "")
	{
		if($query == "")
			$query = $this->mysql_query;
		else
			$this->mysql_query = $query;
		
                $query_ = mysql_query($query) or die(mysql_error() . "<br />" . $query);
                
                return mysql_num_rows($query_);
	}
	
	
	private $mysql_host = "";
	private $mysql_username = "";
	private $mysql_password = "";
	private $mysql_database = "";
	private $mysql_connection = NULL;
	private $mysql_connection_open = false;
	private $mysql_query = "";
}
?>
