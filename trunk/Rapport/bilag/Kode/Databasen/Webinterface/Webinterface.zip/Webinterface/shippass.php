<div class="bodytext" style="padding:12px;" align="justify">
			
				<strong>Tast din kode til BROS		  </strong><br />
				<br />
				Om du har logon tast din kode
				<?php include 'pass_form.php'; ?>
				<?php include 'godkend.php'; ?>
</div>