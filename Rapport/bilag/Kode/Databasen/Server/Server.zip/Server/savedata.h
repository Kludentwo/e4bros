// Projekt		BROS 4 semester semesterprojekt
//
// Fil			savedata.h
//
// Beskrivelse	Implementering af klassen savedata
//
// Forfatter	MH
//
// Version		1.0 - oprindelig version

#ifndef SAVEDATA_H
#define SAVEDATA_H
#include <QObject>
#include "update.h"
#include "server.h"
#include "tcp.h"
#include "enumdekrypteringskode.h"

namespace Ui {
class savedata;
}
class saveData
{
public:
    saveData();
    void save(save_data tmp);

signals:
    void addLogSave(QString);
};


#endif // SAVEDATA_H
