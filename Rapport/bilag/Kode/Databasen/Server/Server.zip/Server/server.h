// Projekt		BROS 4 semester semesterprojekt
//
// Fil			server.h
//
// Beskrivelse	Implementering af klassen server
//
// Forfatter	MH
//
// Version		1.2 - oprindelig version


#ifndef SERVER_H
#define SERVER_H

#include <QMainWindow>
#include <QtGui/QMainWindow>
#include <QWebView>
#include <QUrl>
#include "msgServer.h"

namespace Ui {
class Server;
}

class Server : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit Server(QWidget *parent = 0);
    ~Server();

public slots:
    void addLogEntry(QString);


private slots:
    void on_closeServer_clicked();
    void on_webDatabase_clicked();




private:
    Ui::Server *ui;
    QWebView* m_pWebView;
};



#endif // SERVER_H
