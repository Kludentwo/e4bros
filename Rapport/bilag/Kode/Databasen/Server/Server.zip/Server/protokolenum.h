//	THE BRO SYSTEM
//	VERSION 3.6
//	Protokolbeskrivelse for UART mellem Kontrolinterfacet (KI) og Styringsmodulet (SM)
//	E4 Gruppe3
//	Forfatter: Rasmus Lund
//	Senest opdateret: 22-11-2012


#ifndef UARTENUM_H
#define UARTENUM_H

enum Kommando
{
//SYSTEMOPSTART:
CMD_INIT = 101, //KI->SM
ACK_INIT = 201, //SM->KI

//AUTOMATISK STYRING
CMD_AUTO = 102, //Sendes n�r der skiftes status fra manuel vinkling til automatisk regulering
ACK_AUTO = 202, //Sendes n�r der er modtaget CMD_AUTO og automatisk regulering er igangsat.

//MANUEL STYRING
CMD_MANU = 103, //Sendes n�r brugeren �nsker en manuel vinkling. Efterf�lgende sendes v�rdien af vinklen.
//KI->SM: VINKEL
ACK_MANU = 203, //Sendes fra SM n�r v�rdien af vinklen er modtaget

//VBTE1_STATUS_REQ
REQ_VBTE1_STATUS = 112, //Sendes n�r KI �nsker at modtage statusen for vbte1
STATUS_VBTE1 = 212, //Sendes n�r der er modtaget REQ_VBTE1_STATUS. Efterf�lgende sendes v�rdien for NIVEAU. Derefter STATUS
//SM->KI: NIVEAU SOM MANULEVEL-ENUM
//SM->KI: STATUS (0 = lukket, 1 = ind, 2 = ud)


//VBTE2_STATUS_REQ
REQ_VBTE2_STATUS = 113, //Sendes n�r KI �nsker at modtage statusen for vbte2
STATUS_VBTE2 = 213, //Sendes n�r der er modtaget REQ_VBTE2_STATUS. Efterf�lgende sendes v�rdien for NIVEAU. Derefter STATUS
//SM->KI: NIVEAU SOM MANULEVEL-ENUM
//SM->KI: STATUS (0 = lukket, 1 = ind, 2 = ud)

//H�LDNINGSREQUEST
REQ_HAELDNING = 114, //Sendes n�r KI �nsker h�ldningen af skibet
STATUS_HAELDNING = 214, //Sendes n�r der er modtaget REQ_HAELDNING. Efterf�lgende sendes v�rdien for h�ldningen.
//SM->KI: HAELDNINGSV�RDI

//PROGRAMTERMINERING
CMD_TERMINATION = 150, //Sendes n�r programmet lukkes ned.
ACK_TERMINATION = 250, //Sendes som bekr�ftigelse p� at SM afventer at programmet starter igen.

//DEFAULT: HVIS SM IKKE FORSTOD BESKEDEN
UNKNOWN = 255
};


enum Level
{
    NUL,
	SBSTART,
    STYR05,
    STYR10,
    STYR15,
    STYR20,
    STYR25,
	STYR30,
	STYR35,
	STYR40,
	STYR45,
	STYR50,
	STYR55,
	STYR60,
	STYR65,
	STYR70,
	STYR75,
	SBSLUT,
	BBSTART,
    BAG05,
    BAG10,
    BAG15,
    BAG20,
    BAG25,
	BAG30,
	BAG35,
	BAG40,
	BAG45,
	BAG50,
	BAG55,
	BAG60,
	BAG65,
	BAG70,
	BAG75,
	BBSLUT
};

#endif // UARTENUM_H
