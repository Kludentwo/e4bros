// Projekt		BROS 4 semester semesterprojekt
//
// Fil			savedata.cpp
//
// Beskrivelse	Implementering af klassen savedata
//
// Forfatter	MH
//
// Version		1.0 - oprindelig version

#include "savedata.h"
#include <QFile>
#include <QString>
#include <QDebug>
#include <QListWidgetItem>


saveData::saveData()
{

}

void saveData::save(save_data tmp)
{

    int level = tmp.LEVEL_.toInt();
    enumDeKrypteringskode w;
   int tmplevel = w.levelEnumConverterAndSetter(level);

    //Write to text
    QString filename = "/Library/WebServer/Documents/BROS/ship.txt";
    QFile file(filename);
    if(file.open(QIODevice::ReadWrite))
    {
        QTextStream stream(&file);
        stream<< tmp.ID_<<" "<<tmp.STYRBORD_<<"% "<<tmp.BAGBORD_<<"% "<<tmplevel<<" "<<tmp.TIME_<<"s"<<endl;
    }

    qDebug()<<"Data gemt: "<<tmp.ID_<<" "<<tmp.STYRBORD_<<"% "<<tmp.BAGBORD_<<"% "<<tmplevel<<" "<<tmp.TIME_<<"s";
    saveData();

}

