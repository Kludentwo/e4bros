// Projekt		BROS 4 semester semesterprojekt
//
// Fil			enumDeKrypteringskode.h
//
// Beskrivelse	Implementering af klassen enumDeKrypteringskode
//
// Forfatter	MH
//
// Version		1.0 - oprindelig version

#ifndef ENUMDEKRYPTERINGSKODE_H
#define ENUMDEKRYPTERINGSKODE_H
#include "protokolenum.h"


class enumDeKrypteringskode
{
public:
    int levelEnumConverterAndSetter(int level);

};

#endif // ENUMDEKRYPTERINGSKODE_H
