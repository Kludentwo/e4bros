#ifndef SPLIT_H
#define SPLIT_H

class split
{
public:
    split();
};

#endif // SPLIT_H
