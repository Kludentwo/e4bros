// Projekt		BROS 4 semester semesterprojekt
//
// Fil			enumDeKrypteringskode.cpp
//
// Beskrivelse	Implementering af klassen enumDeKrypteringskode
//
// Forfatter	MH
//
// Version		1.0 - oprindelig version


#include "enumdekrypteringskode.h"
#include <QDebug>
#include "update.h"
#include <iostream>

using namespace std;

int enumDeKrypteringskode::levelEnumConverterAndSetter(int level)
{

    cout<<"Level: "<<level<<endl;

    for(int i = SBSTART; i < SBSLUT; i++)
    {
        if( i == level )
        {
            qDebug() << ((level-SBSTART)*0.5);
            qDebug() << "i: " << i << "level: " << level;
            return level;
        }
    }
    qDebug() << "Vi hÊlder til BAGBORD";
    for(int j = BBSTART; j < BBSLUT; j++)
    {
        if( j == level )
        {
            qDebug() << ((level-BBSTART)*0.5);
            qDebug() << "j: " << j << "level: " << level;
            return level;
        }
    }
    qDebug() << "Level: " << level;

    return level;

}


