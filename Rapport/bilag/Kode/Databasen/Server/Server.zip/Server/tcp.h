// Projekt		BROS 4 semester semesterprojekt
//
// Fil			tcp.h
//
// Beskrivelse	Implementering af klassen tcp
//
// Forfatter	MH
//
// Version		3.0 - oprindelig version



#ifndef TCP_H
#define TCP_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QWebView>
#include <QUrl>
#include <QDebug>

#include "server.h"
#include "savedata.h"
#include "update.h"



namespace Ui {
class Tcp;
}
class Tcp : public QObject
{
    Q_OBJECT
public:
    explicit Tcp(Server* s);

private slots:
    void acceptConnection(void);
    void startRead(void);


signals:
    void addLogEntry(QString);


private:
    QTcpServer server;
    QTcpSocket* client;
};

#endif // TCP_H




