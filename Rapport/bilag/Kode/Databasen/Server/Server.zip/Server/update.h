// Projekt		BROS 4 semester semesterprojekt
//
// Fil			update.h
//
// Beskrivelse	Implementering af header update
//
// Forfatter	MH
//
// Version		1.2 - oprindelig version

#ifndef UPDATE_H
#define UPDATE_H
struct save_data
{
    QString ID_;
    QString STYRBORD_;
    QString BAGBORD_;
    QString LEVEL_;
    QString TIME_;
    QString kiCheck_;
    QString addLogUpdate;


};


#endif // UPDATE_H
