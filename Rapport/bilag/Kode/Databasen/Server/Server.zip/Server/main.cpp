// Projekt		BROS 4 semester semesterprojekt
//
// Fil			main.cpp
//
// Beskrivelse	Implementering af systemet Server
//
// Forfatter	MH
//
// Version		4.0 - oprindelig version

#include <QtGui/QApplication>
#include "server.h"
#include "tcp.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Server w;
    Tcp myTCP(&w);
    w.show();
    
    return a.exec();
}
