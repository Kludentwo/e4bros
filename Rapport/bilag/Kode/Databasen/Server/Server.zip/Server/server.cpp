// Projekt		BROS 4 semester semesterprojekt
//
// Fil			server.cpp
//
// Beskrivelse	Implementering af klassen server
//
// Forfatter	MH
//
// Version		1.2 - oprindelig version


#include "server.h"
#include "ui_server.h"
#include <QMessageBox>
#include <QDebug>

Server::Server(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Server)
{
    ui->setupUi(this);
    ui->closeServer->setText("Luk server");
    ui->webDatabase->setText("Database");
    ui->listServer->insertItem(0, "Server startet");

    qDebug()<<"Server kører";
}

Server::~Server()
{
    delete ui;
}


void Server:: addLogEntry(QString s)
{
    ui->listServer->insertItem(0, s);
}


void Server::on_webDatabase_clicked()
{
    m_pWebView = new QWebView();
    m_pWebView->setGeometry(0,0,1000,1000);

    m_pWebView->load(QUrl("http://localhost/BROS/index.php?page=shippass"));
    m_pWebView->show();

    ui->listServer->insertItem(0, "Web database startet");
    qDebug()<<"Web database åbnet";
}

void Server::on_closeServer_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Title here", "Vil du lukke serveren", QMessageBox::Yes | QMessageBox::No);

    if(reply == QMessageBox::Yes)
    {
        close();
    }

    qDebug()<<"Luk knap aktiveret";
}


